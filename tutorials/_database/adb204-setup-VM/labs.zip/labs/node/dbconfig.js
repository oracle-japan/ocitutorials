module.exports= {
                dbuser: 'admin',
                dbpassword: 'Welcome12345#',
                connectString: 'atp01_tp'
                }
