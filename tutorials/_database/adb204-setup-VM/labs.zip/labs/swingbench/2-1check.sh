#!/bin/sh


./swingbench/bin/sbutil -soe -cf ~/labs/wallets_atp01/Wallet_atp01.zip \
         -cs atp01_tp -u soe -p Welcome12345# \
         -val

./swingbench/bin/sbutil -soe -cf ~/labs/wallets_atp01/Wallet_atp01.zip \
         -cs atp01_medium -u soe -p Welcome12345# \
         -stats

./swingbench/bin/sbutil -soe -cf ~/labs/wallets_atp01/Wallet_atp01.zip \
         -cs atp01_medium -u soe -p Welcome12345# \
         -tables
