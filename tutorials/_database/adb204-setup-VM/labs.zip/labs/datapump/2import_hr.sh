#!/bin/sh


impdp admin/Welcome12345#@atp01_high \
  credential=WORKSHOP_CREDENTIAL \
  parallel=4 \
  schemas=HR \
  directory=DATA_PUMP_DIR \
  remap_tablespace=users:data \
  dumpfile=https://objectstorage.ap-tokyo-1.oraclecloud.com/n/XXXX/b/adb-hol-bucket01/o/export_hr_%u.dmp \
  logfile=DATA_PUMP_DIR:import_hr.log

