import os
import cx_Oracle

conn = cx_Oracle.connect(os.environ.get('ORAUSER'), os.environ.get('ORAPASS'), os.environ.get('ORATNS'))
print(conn.version)
conn.close()
