#!/bin/sh


./swingbench/bin/oewizard -cf ~/labs/wallets_atp01/Wallet_atp01.zip \
           -cs atp01_tp \
           -ts DATA \
           -dbap Welcome12345# \
           -dba admin \
           -u soe \
           -p Welcome12345# \
           -async_off \
           -scale 5 \
           -hashpart \
           -create \
           -cl \
           -v

