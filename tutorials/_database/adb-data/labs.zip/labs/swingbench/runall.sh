#!/bin/sh


curl http://www.dominicgiles.com/swingbench/swingbenchlatest.zip -o swingbench.zip

unzip  swingbench.zip

export TNS_ADMIN=/home/oracle/labs/wallets_atp01

./1install.sh
./2-1check.sh
./2-2pre.sh

echo finish.



