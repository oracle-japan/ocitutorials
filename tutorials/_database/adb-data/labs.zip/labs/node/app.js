const port = 3030;
const http = require('http');
var os = require('os');
var hostname = os.hostname();
const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello World\n');
});
server.listen(port, hostname, () => {
  console.log(`Server running at http://<Your Compute IP Address>:${port}/`);
});
