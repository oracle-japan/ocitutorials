import os
import oracledb

un = os.environ.get('ORAUSER')
pw = os.environ.get('ORAPASS')
cs = os.environ.get('ORATNS')
wallet_dir = os.environ.get('TNS_ADMIN')
wallet_pw = os.environ.get('WALLETPASS')

conn = oracledb.connect(user=un, password=pw, dsn=cs, config_dir=wallet_dir, wallet_location=wallet_dir, wallet_password=wallet_pw)
print(conn.version)
conn.close()