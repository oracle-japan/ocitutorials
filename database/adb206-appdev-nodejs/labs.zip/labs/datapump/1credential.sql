
BEGIN
  DBMS_CLOUD.DROP_CREDENTIAL(
    credential_name => 'WORKSHOP_CREDENTIAL'
  );
END;
/

BEGIN
  DBMS_CLOUD.CREATE_CREDENTIAL(
    credential_name => 'WORKSHOP_CREDENTIAL',
    username => 'adb@handson.com',
    password => 'xxxxxxxxxxx'
  );
END;
/
