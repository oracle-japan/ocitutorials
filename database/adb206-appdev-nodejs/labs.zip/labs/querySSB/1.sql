set timing on

select count(1) from ssb.dwdate;
select count(1) from ssb.part;
select count(1) from ssb.supplier;
select count(1) from ssb.customer;
select count(1) from ssb.lineorder;
