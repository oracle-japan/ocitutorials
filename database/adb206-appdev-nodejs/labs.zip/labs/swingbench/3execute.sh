#!/bin/sh


./swingbench/bin/charbench -c ~/labs/swingbench/swingbench/configs/SOE_Server_Side_V2.xml \
         -cf ~/labs/wallets_atp01/Wallet_atp01.zip \
         -cs atp01_tp -u soe -p Welcome12345# \
         -v users,tpm,tps,vresp \
         -intermin 0 \
         -intermax 0 \
         -min 0 \
         -max 0 \
         -uc 64 \
         -di SQ,WQ,WA
