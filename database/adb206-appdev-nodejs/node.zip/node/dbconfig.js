module.exports= {
                dbuser: 'admin',
                dbpassword: 'Welcome123#XX',
                connectString: 'atpXX_tp'
                }
