if [ "${SERVER_NAME}" = "MServer1" ] ; then
  USER_MEM_ARGS="-Xms512M  -Xmx512M"
  JAVA_OPTIONS="-XX:+UnlockCommercialFeatures  -XX:+FlightRecorder $JAVA_OPTIONS"
fi

