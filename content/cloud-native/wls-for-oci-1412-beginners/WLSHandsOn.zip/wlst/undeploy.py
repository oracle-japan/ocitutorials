# Properties
pHostName='localhost'
pPortNumber='7001'
pUserName='weblogic'
pPassWord='welcome1'
pAppName='OracleWebMall'
pVersion='1.0.0'
pTarget='MServer1'

# connect
connect(pUserName, pPassWord, 't3://' +pHostName +':' + pPortNumber)

# undeplpy
undeploy(appName=pAppName,targets=pTarget,archiveVersion=pVersion)

# disconnect
disconnect()

# exit 
exit()






