
# Properties
pHostName='localhost'
pPortNumber='7001'
pUserName='weblogic'
pPassWord='welcome1'
pAppName='ClusterServlet'
pAppPath='/home/oracle/WLSHandsOn/ClusterServlet.war'
pTarget='AdminServer'

# Connect
connect(pUserName, pPassWord, 't3://' +pHostName +':' + pPortNumber)
# deploy
deploy(appName=pAppName,path=pAppPath,targets=pTarget,upload='false')

# disconnect
disconnect()

# exit
exit()






